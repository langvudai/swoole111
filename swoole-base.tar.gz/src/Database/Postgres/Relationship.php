<?php

namespace Src\Database\Postgres;

use Src\Database\Connection;

class Relationship
{
    private $cols;

    /** @var null|array|Recordset */
    private $related_data = null;

    private $where_raw = null;

    /**
     * Relationship constructor.
     *
     * @param Connection $connection
     * @param array $records
     * @param string $name
     * @param string $table_name
     * @param callable|null $callback
     * @param array $relation_keys
     */
    public function __construct(Connection $connection, private array $records, string $name, string $table_name, ?callable $callback, private array $relation_keys)
    {
        $this->createWhereRaw($table_name);
        $this->getRelatedData($table_name, $connection, $callback);
        $this->mapData($name);
    }

    /**
     * @return array
     */
    public function getArray(): array
    {
        return $this->records;
    }

    private function createWhereRaw(string $table_name)
    {
        $this->cols = array_keys($this->relation_keys);

        $where = 'ROW(' . implode(', ', array_map(fn($c) => QueryBuilder::quoteIdentifier($c, $table_name) , $this->relation_keys)) . ')';

        $conditions = array_map(function ($item) {
            $item = array_reduce($this->cols, function($ax, $dx) use ($item) {
                $ax[] =  isset($item[$dx]) && !empty($item[$dx]) ? $this->escapeValue($item[$dx]) : null;
                return $ax;
            }, []);

            return sprintf("ROW('%s')", implode("', '", $item));
        }, $this->records);

        $this->where_raw = $where . ' IN ('. implode(', ', $conditions) .')';
    }

    private function getRelatedData(string $table_name, Connection $connection, ?callable $callback)
    {
        $builder = new QueryBuilder($connection);
        $builder->table($table_name)->whereRaw($this->where_raw);
        $result = null;

        if ($callback) {
            $result = $callback($builder);
        }

        if ($result instanceof Recordset) {
            $this->related_data = $result;
        } else {
            $this->related_data = $builder->get()->toArray();
        }
    }

    private function mapData(string $name)
    {
        if (is_array($this->related_data)) {
            $this->mapDataArray($name);
        }

        if ($this->related_data instanceof Recordset) {
            $this->mapRecords($name);
        }
    }

    private function mapRecords(string $name)
    {
        foreach ($this->records as $i => $pre_item) {
            $condition = array_reduce($this->cols, function ($condition, $pre_col) use ($pre_item) {
                $condition[$this->relation_keys[$pre_col]] = $pre_item[$pre_col];
                return $condition;
            }, []);

            if (isset($pre_item[$name])) {
                $this->records[$i]["_$name"] = $this->related_data->filter($condition);;
            } else {
                $this->records[$i][$name] = $this->related_data->filter($condition);;
            }
        }
    }

    private function mapDataArray(string $name)
    {
        foreach ($this->records as $i => $pre_item) {
            $record = array_filter($this->related_data, fn ($item) =>
                array_reduce($this->cols, fn ($ok, $pre_col) =>
                    $ok &&
                    isset($pre_item[$pre_col]) &&
                    isset($item[$this->relation_keys[$pre_col]]) &&
                    $pre_item[$pre_col] === $item[$this->relation_keys[$pre_col]]
                , true)
            );

            if (isset($pre_item[$name])) {
                $this->records[$i]["_$name"] = $record ?? [];
            } else {
                $this->records[$i][$name] = $record ?? [];
            }
        }
    }

    /**
     * @param string $value
     * @return string
     */
    private function escapeValue(string $value): string
    {
        return str_replace(
            ["\\", "'", '"', "\0", "\n", "\r", "\x1a"],
            ["\\\\", "''", '""', "\\0", "\\n", "\\r", "\\Z"],
            $value
        );
    }
}
