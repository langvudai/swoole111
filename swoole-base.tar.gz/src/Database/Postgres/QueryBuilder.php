<?php

namespace Src\Database\Postgres;

use Src\Database\DbTable;
use Src\Database\Connection;
use Src\Database\QueryBuilderInterface;
use Src\Database\RecordsetInterface;
use SwooleBase\Foundation\Traits\MacroAble;

class QueryBuilder implements QueryBuilderInterface
{
    use MacroAble;

    /** @var Connection */
    protected $connection;

    /** @var string */
    protected $table;

    /** @var array */
    protected $query;

    /** @var DbTable|null */
    protected $db_table;

    /** @var array */
    private array $relations = [];

    public function __construct(Connection $connection, DbTable $db_table = null)
    {
        $this->connection = $connection;

        if ($db_table) {
            $this->db_table = $db_table;
            $this->table = $db_table->getTable();
        }

        $this->query = [
            'SELECT' => '*',
            'WHERE' => [],
            'JOIN' => [],
            'ORDER BY' => [],
            'GROUP BY' => [],
            'HAVING' => [],
            'LIMIT' => null,
            'OFFSET' => null,
        ];
    }

    /**
     * @return string
     */
    public function sqlCommand(): string
    {
        return $this->buildQuery();
    }

    /**
     * @return RecordsetInterface
     */
    public function get(): RecordsetInterface
    {
        $sql = $this->buildQuery();
        $stmt = $this->connection->getDriver()->prepare($sql);
        $this->bindValues($stmt);
        $stmt->execute();
        $arr = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        if (!empty($arr) && $this->relations && is_array($this->relations)) {
            foreach ($this->relations as $name => $relation) {
                $arr = (new Relationship($this->connection, $arr, $name, $relation['table_name'], $relation['callback'], $relation['relation_keys']))->getArray();
            }
        }

        return new Recordset($this->connection, $arr, $this->db_table ? get_class($this->db_table) : null);
    }

    /**
     * @param string $table_name
     * @param array $relation_keys
     * @param callable|null $callback
     * @param string $alias
     * @return $this
     */
    public function contain(string $table_name, array $relation_keys, callable $callback = null, string $alias = ''): QueryBuilder
    {
        if (empty($alias)) {
            $this->relations[$table_name] = compact('table_name', 'callback', 'relation_keys');
        } else {
            $this->relations[$alias] = compact('table_name', 'callback', 'relation_keys');
        }

        return $this;
    }

    /**
     * @return string
     */
    public function getTable(): string
    {
        return $this->table;
    }

    /**
     * @param string $table
     * @return QueryBuilder
     */
    public function table(string $table): QueryBuilder
    {
        $this->table = $table;
        return $this;
    }

    /**
     * @param $columns
     * @return $this
     */
    public function select(string|array $columns): QueryBuilder
    {
        if (!is_array($columns) && !empty($columns)) {
            $this->query['SELECT'] = $columns;
            return $this;
        }

        $columns = array_map(function ($column) {
            if (is_string($column) && '*' === trim($column)) {
                return $column;
            }

            return self::quoteIdentifier($column);
        }, $columns);

        $this->query['SELECT'] = implode(', ', $columns);

        return $this;
    }

    /**
     * @param string $sql
     * @return $this
     */
    public function whereRaw(string $sql): QueryBuilder
    {
        $this->query['WHERE'][] = ['RAW', $sql];
        return $this;
    }

    /**
     * @param string|object $column
     * @param $operator
     * @param $value
     * @return $this
     */
    public function where(string|object $column, $operator, $value): QueryBuilder
    {
        $column = self::quoteIdentifier($column);
        $this->query['WHERE'][] = [$column, $operator, $value];
        return $this;
    }

    /**
     * @param string|object $column
     * @param $operator
     * @param $value
     * @return $this
     */
    public function orWhere(string|object $column, $operator, $value): QueryBuilder
    {
        $column = self::quoteIdentifier($column);
        $this->query['WHERE'][] = ['OR', $column, $operator, $value];
        return $this;
    }

    /**
     * @param string $table
     * @param $on
     * @return $this
     */
    public function join(string $table, $on): QueryBuilder
    {
        $this->query['JOIN'][] = ['table' => $table, 'on' => $on];
        return $this;
    }

    /**
     * @param string $table
     * @param $on
     * @return $this
     */
    public function leftJoin(string $table, $on): QueryBuilder
    {
        $this->query['JOIN'][] = ['type' => 'LEFT', 'table' => $table, 'on' => $on];
        return $this;
    }

    /**
     * @param string $table
     * @param $on
     * @return $this
     */
    public function rightJoin(string $table, $on): QueryBuilder
    {
        $this->query['JOIN'][] = ['type' => 'RIGHT', 'table' => $table, 'on' => $on];
        return $this;
    }

    /**
     * @param string $column
     * @param bool $direction_asc
     * @return $this
     */
    public function orderBy(string $column, bool $direction_asc = true): QueryBuilder
    {
        $column = self::quoteIdentifier($column);
        $this->query['ORDER BY'][] = [$column, $direction_asc ? 'ASC' : 'DESC'];
        return $this;
    }

    /**
     * @param $columns
     * @return $this
     */
    public function groupBy($columns): QueryBuilder
    {
        $this->query['GROUP BY'] = is_array($columns) ? $columns : [$columns];
        return $this;
    }

    /**
     * @param $column
     * @param $operator
     * @param $value
     * @return $this
     */
    public function having($column, $operator, $value): QueryBuilder
    {
        $this->query['HAVING'][] = [$column, $operator, $value];
        return $this;
    }

    /**
     * @param int $value
     * @return $this
     */
    public function limit(int $value): QueryBuilder
    {
        $this->query['LIMIT'] = $value;
        return $this;
    }

    /**
     * @param int $value
     * @return $this
     */
    public function offset(int $value): QueryBuilder
    {
        $this->query['OFFSET'] = $value;
        return $this;
    }

    /**
     * @return string
     */
    protected function buildQuery(): string
    {
        $sql = "SELECT {$this->query['SELECT']} FROM {$this->table}";

        foreach ($this->query['JOIN'] as $join) {
            $joinType = $join['type'] ?? 'JOIN';
            $sql .= " {$joinType} {$join['table']} ON {$join['on']}";
        }

        if (!empty($this->query['WHERE'])) {
            $conditions = [' WHERE '];

            foreach ($this->query['WHERE'] as $condition) {
                if ('RAW' === $condition[0]) {
                    $conditions[] = $condition[1];
                } elseif ('OR' === $condition[0]) {
                    $conditions[] = "OR {$condition[1]} {$condition[2]} ?";
                } else {
                    $conditions[] = "{$condition[0]} {$condition[1]} ?";
                }
            }

            $sql .= preg_replace(['/\sWHERE(AND|OR|\s)+\s/', '/\sAND\s+OR\s/'], [' WHERE ', ' OR '], implode(' AND ', $conditions));
        }

        if (!empty($this->query['GROUP BY'])) {
            $sql .= " GROUP BY " . implode(', ', $this->query['GROUP BY']);
        }

        if (!empty($this->query['HAVING'])) {
            $havingConditions = [];
            foreach ($this->query['HAVING'] as $condition) {
                $havingConditions[] = "{$condition[0]} {$condition[1]} ?";
            }
            $sql .= " HAVING " . implode(' AND ', $havingConditions);
        }

        if (!empty($this->query['ORDER BY'])) {
            $order_by = [];
            foreach ($this->query['ORDER BY'] as $order) {
                $order_by[] = "{$order[0]} {$order[1]}";
            }
            $sql .= " ORDER BY " . implode(', ', $order_by);
        }

        if (!is_null($this->query['LIMIT'])) {
            $sql .= " LIMIT {$this->query['LIMIT']}";
        }

        if (!is_null($this->query['OFFSET'])) {
            $sql .= " OFFSET {$this->query['OFFSET']}";
        }

        return $sql;
    }

    protected function bindValues($stmt)
    {
        $binds = array_values(array_filter($this->query['WHERE'], fn($item) => 'RAW' !== $item[0]));

        foreach ($binds as $index => $condition) {
            $stmt->bindValue($index + 1, 'OR' === $condition[0] ? $condition[3] : $condition[2]);
        }

        foreach ($this->query['HAVING'] as $index => $condition) {
            $stmt->bindValue(count($binds) + $index + 1, $condition[2]);
        }
    }

    /**
     * @param string|object $identifier
     * @param string $table
     * @return string
     */
    public static function quoteIdentifier(string|object $identifier, string $table = ''): string
    {
        if (!is_string($identifier)) {
            return "$identifier";
        }

        if (!empty($table)) {
            $table = "$table.";
        }

        return $table . '"' . str_replace('"', '""', trim($identifier)) . '"';
    }
}
