<?php

namespace Src\Database\Postgres;

use Src\Database\Connection;
use Src\Database\RecordsetInterface;
use SwooleBase\Foundation\Abstracts\ModelList;

class Recordset extends ModelList implements RecordsetInterface
{
    /**
     * Recordset constructor.
     * @param Connection $connection
     * @param array $items
     * @param string|null $model_class
     */
    public function __construct(private Connection $connection, array $items, string $model_class = null)
    {
        parent::__construct($items, $model_class);
    }

    protected function transform($item): mixed
    {
        if (isset($this->model_class)) {
            return parent::transform($item);
        }

        return $item;
    }

    /**
     * @param string $model_class
     * @return Recordset
     */
    public function setModel(string $model_class): Recordset
    {
        $this->model_class = $model_class;
        return $this;
    }

    /**
     * @param string ...$column_names
     * @return array
     */
    public function getColumnValue(string ...$column_names): array
    {
        asort($column_names);

        return array_map(function ($item) use ($column_names) {
            return array_reduce($column_names, function($ax, $dx) use ($item) {
                $ax[] =  $item[$dx] ?? null;
                return $ax;
            }, []);
        }, $this->items);
    }

    /**
     * @param string ...$column_names
     * @return array
     */
    public function getColumn(string ...$column_names): array
    {
        return array_map(fn ($item) => array_filter($item, fn($key) => in_array($key, $column_names), ARRAY_FILTER_USE_KEY), $this->items);
    }

    public function toArray(): array
    {
        return iterator_to_array($this->getIterator());
    }

    /**
     * @param array<column,value_filter> $condition
     * @return Recordset
     */
    public function filter(array $condition): Recordset
    {
        $item = array_values(array_filter($this->items, fn($item) =>
            array_reduce(array_keys($condition), fn($ok, $col) =>
                $ok && isset($item[$col]) && $item[$col] === $condition[$col], true)));
        return new Recordset($this->connection, is_array($item) ? $item : [], $this->model_class ?? null);
    }

    /**
     * @param string $col
     * @param bool $overwrite
     * @return Recordset
     */
    public function identify(string $col, bool $overwrite = false): Recordset
    {
        $new_items = [];

        if ($overwrite) {
            foreach ($this->items as $row) {
                $new_items[$row[$col]] = $row;
            }

            return new Recordset($this->connection, $new_items, $this->model_class ?? null);
        }

        foreach ($this->items as $row) {
            if (!isset($new_items[$row[$col]])) {
                $new_items[$row[$col]] = [$row];
            } else {
                $new_items[$row[$col]][] = $row;
            }
        }

        return new Recordset($this->connection, $new_items, $this->model_class ?? null);
    }

    /**
     * @param string ...$columns
     * @return Recordset
     */
    public function toTree(string ...$columns): Recordset
    {
        $new_items = [];
        $point = null;
        foreach ($this->items as $r) {
            $r = array_map('stripcslashes', $r);
            foreach ($columns as $i => $c) {
                if ($i == 0) {
                    if (!isset($new_items[$r[$c]])) {
                        $new_items[$r[$c]] = array();
                    }
                    $point = &$new_items[$r[$c]];
                } else {
                    if (!isset($point[$r[$c]])) {
                        $point[$r[$c]] = array();
                    }
                    $point = &$point[$r[$c]];
                }
            }
            $point = true;
        }

        return new Recordset($this->connection, $new_items, $this->model_class ?? null);
    }

    /**
     * @param string $table_name
     * @param array $relation_keys
     * @param callable|null $callback
     * @param string $alias
     * @return $this
     */
    public function contain(string $table_name, array $relation_keys, callable $callback = null, string $alias = ''): Recordset
    {
        $name = empty($alias) ? $table_name : $alias;
        $this->items = (new Relationship($this->connection, $this->items, $name, $table_name, $callback, $relation_keys))->getArray();
        return $this;
    }
}
