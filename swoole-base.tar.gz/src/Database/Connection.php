<?php

namespace Src\Database;

abstract class Connection
{
    const POSTGRESQL = 'pgsql';

    private static $drivers = [];

    private static $max_connections = 10;

    public static function config($connection_name, string $driver, array $config, int $max_connections = 10)
    {
        if (!$driver || !class_exists($driver)) {
            return;
        }

        self::$drivers[$connection_name] = ['connection' => [], 'driver' => $driver, 'config' => $config];
        self::$max_connections = $max_connections;
    }

    /**
     * @param null $connection_name
     * @return Connection|null
     */
    public static function createOrReceive($connection_name = null): ?Connection
    {
        $connection_name = $connection_name ?? key(self::$drivers);

        if (!$connection_name || !isset(self::$drivers[$connection_name])) {
            return null;
        }

        $connection = array_pop(self::$drivers[$connection_name]['connection']);

        if ($connection instanceof Connection) {
            return $connection;
        }

        return self::createConnection($connection_name, self::$drivers[$connection_name]['driver']);
    }

    /**
     * @param Connection $connection
     * @param null $connection_name
     */
    public static function release(Connection $connection, $connection_name = null)
    {
        $connection_name = $connection_name ?? key(self::$drivers);

        if (count(self::$drivers[$connection_name]['connection']) < self::$max_connections) {
            self::$drivers[$connection_name]['connection'][] = $connection;
        } else {
            $connection = null;
        }
    }

    /**
     * @param $connection_name
     * @param string $driver
     * @return Connection|null
     */
    private static function createConnection($connection_name, string $driver): ?Connection
    {
        if (is_subclass_of($driver, Connection::class)) {
            $connection = new $driver(self::$drivers[$connection_name]['config']);
            self::$drivers[$connection_name]['connection'][] = $connection;
            return $connection;
        }

        return null;
    }

    abstract public function getDriver();

    /**
     * @param string $sql
     * @param array $binds
     * @return mixed
     */
    abstract public function statement(string $sql, array $binds = []): mixed;

    /**
     * @param callable $callback
     */
    abstract public function transaction(callable $callback);

    abstract public function find($table, ?string $where_column, $value, string $select = '*');

    abstract public function create($table, array $attributes, string $primary_key = 'id');

    abstract public function update($table, string $where_column, $where_value, array $attributes);

    abstract public function delete($table, string $where_column, $where_value);

    abstract public function query(string $sql, array $binds = []): ?RecordsetInterface;
}
