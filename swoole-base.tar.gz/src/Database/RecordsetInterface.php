<?php

namespace Src\Database;

interface RecordsetInterface
{
    /**
     * @param string $model_class
     * @return $this
     */
    public function setModel(string $model_class): RecordsetInterface;

    /**
     * @param string ...$column_names
     * @return array
     */
    public function getColumnValue(string ...$column_names): array;

    /**
     * @param string ...$column_names
     * @return array
     */
    public function getColumn(string ...$column_names): array;

    public function toArray(): array;

    /**
     * @param array<column,value_filter> $condition
     * @return $this
     */
    public function filter(array $condition): RecordsetInterface;

    /**
     * @param string $col
     * @param bool $overwrite
     * @return $this
     */
    public function identify(string $col, bool $overwrite = false): RecordsetInterface;

    /**
     * @param string ...$columns
     * @return $this
     */
    public function toTree(string ...$columns): RecordsetInterface;

    /**
     * @param string $table_name
     * @param array $relation_keys
     * @param callable|null $callback
     * @param string $alias
     * @return $this
     */
    public function contain(string $table_name, array $relation_keys, callable $callback = null, string $alias = ''): RecordsetInterface;
}
