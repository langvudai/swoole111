<?php

namespace Src\Database;

interface QueryBuilderInterface
{
    public function sqlCommand(): string;

    /**
     * @return RecordsetInterface
     */
    public function get(): RecordsetInterface;

    /**
     * @param string $table_name
     * @param array $relation_keys
     * @param callable|null $callback
     * @param string $alias
     * @return $this
     */
    public function contain(string $table_name, array $relation_keys, callable $callback = null, string $alias = ''): QueryBuilderInterface;

    /**
     * @return string
     */
    public function getTable(): string;

    /**
     * @param string $table
     * @return $this
     */
    public function table(string $table): QueryBuilderInterface;

    /**
     * @param $columns
     * @return $this
     */
    public function select(string|array $columns): QueryBuilderInterface;

    /**
     * @param string $sql
     * @return $this
     */
    public function whereRaw(string $sql): QueryBuilderInterface;

    /**
     * @param string|object $column
     * @param $operator
     * @param $value
     * @return $this
     */
    public function where(string|object $column, $operator, $value): QueryBuilderInterface;

    /**
     * @param string|object $column
     * @param $operator
     * @param $value
     * @return $this
     */
    public function orWhere(string|object $column, $operator, $value): QueryBuilderInterface;

    /**
     * @param string $table
     * @param $on
     * @return $this
     */
    public function join(string $table, $on): QueryBuilderInterface;

    /**
     * @param string $table
     * @param $on
     * @return $this
     */
    public function leftJoin(string $table, $on): QueryBuilderInterface;

    /**
     * @param string $table
     * @param $on
     * @return $this
     */
    public function rightJoin(string $table, $on): QueryBuilderInterface;

    /**
     * @param string $column
     * @param bool $direction_asc
     * @return $this
     */
    public function orderBy(string $column, bool $direction_asc = true): QueryBuilderInterface;

    /**
     * @param $columns
     * @return $this
     */
    public function groupBy($columns): QueryBuilderInterface;

    /**
     * @param $column
     * @param $operator
     * @param $value
     * @return $this
     */
    public function having($column, $operator, $value): QueryBuilderInterface;

    /**
     * @param int $value
     * @return $this
     */
    public function limit(int $value): QueryBuilderInterface;

    /**
     * @param int $value
     * @return $this
     */
    public function offset(int $value): QueryBuilderInterface;
}
