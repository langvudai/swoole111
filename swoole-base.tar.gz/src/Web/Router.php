<?php

namespace Src\Web;

use Src\Web\Controllers\IndexController;
use SwooleBase\Foundation\Http\RouteCollector;
use SwooleBase\Foundation\Exception;

class Router implements \SwooleBase\Foundation\Interfaces\Router
{
    public function __construct(RouteCollector $router)
    {
        $router->prefix = '';

        $router->get('/', [IndexController::class, 'index']);
        $router->get('/download', [IndexController::class, 'download']);
        $router->get(RouteCollector::ANY, function () {
            throw new Exception('page not found', ['status_code' => 404]);
        });
    }
}