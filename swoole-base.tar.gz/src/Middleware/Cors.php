<?php

namespace Src\Middleware;

use SwooleBase\Foundation\Http\Response;
use SwooleBase\Foundation\Http\Request;

class Cors
{
    public function __construct(Request $request, Response $response)
    {
        $response->setHeader('Access-Control-Allow-Methods','*');
        $response->setHeader('Access-Control-Allow-Headers', '*');
        $response->setHeader('Access-Control-Allow-Origin','*');
    }

    /**
     * @param Request $request
     * @param string|null $except
     * @return bool
     */
    private function except(Request $request, ?string $except): bool
    {
        if (!$except) {
            return false;
        }

        $uri = explode('?', $request->getUri(), 2)[0];
        $except = trim(str_ireplace('except:', '', $except), '/');

        return (bool)preg_match('@^(?:http://)?([^/]+)/('.$except.')/$@i', $uri.'/');
    }
}