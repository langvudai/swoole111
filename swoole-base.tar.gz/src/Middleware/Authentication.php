<?php

namespace Src\Middleware;

use Src\Api\Models\Client\Client;
use Src\Database\Entities\User;

/**
 * Class Authentication
 * @package Src\Middleware
 *
 * @property int $id
 * @property string $uuid
 * @property string $username
 * @property int $authority
 * @property string $token
 */
final class Authentication
{
    private $attributes = [];

    private $client = null;

    public function __construct(private User $user_entity, private ?array $client_attributes = null)
    {
        $this->attributes = [
            'id' => $this->user_entity->id,
            'uuid' => $this->user_entity->uuid,
            'username' => $this->user_entity->username,
            'authority' => $this->user_entity->role_authority,
            'token' => $this->user_entity->remember_token,
        ];

        if ($this->client_attributes) {
            $this->client = new Client($this->client_attributes);
        }
    }

    /**
     * @param string $name
     * @return mixed|null
     */
    public function __get(string $name)
    {
        return $this->attributes[$name] ?? null;
    }

    public function isAble(int $action, array $arg): bool
    {
        return false;
    }

    public function hasPermission(string $permissionsName): bool
    {
        return false;
    }

    public function isPrivilege(): bool
    {
        return false;
    }

    /**
     * @return Client|null
     */
    public function getClient(): ?Client
    {
        return $this->client;
    }

    /**
     * @return int|null
     */
    public function getClientId(): ?int
    {
        return $this->client_attributes ? ($this->client_attributes['id'] ?? null) : null;
    }

    /**
     * @return string|null
     */
    public function getClientCode(): ?string
    {
        return $this->client_attributes ? ($this->client_attributes['code'] ?? null) : null;
    }
}
