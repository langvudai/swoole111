<?php

namespace Src\Middleware;

use Src\Database\DbTable;
use Src\Database\Entities\User as UserEntity;
use SwooleBase\Foundation\DI;
use SwooleBase\Foundation\Http\Request;
use SwooleBase\Foundation\Http\Response;
use SwooleBase\Foundation\Exception;

class AuthenticateRoute
{
    public function handle(Request $request, Response $response, DI $di)
    {
        $result = $request->getHeaders('authorization');

        if (!$result) {
            throw new Exception('token fail.');
        }

        $result = self::verifyToken($result);

        if (!$result) {
            throw new Exception('token fail.');
        }

        $uuid = $result['payload']['uuid'] ?? '';
        /** @var null|UserEntity $user */
        $user = UserEntity::findUuid($uuid);

        if (!$user) {
            throw new Exception('not user');
        }

        $client = DbTable::connection()->find('clients', 'code', $result['payload']['client'] ?? '');

        if (is_array($client)) {
            $di->setFactory(strtoupper($result['payload']['client'] ?? ''));
            $di->instance(Authentication::class, new Authentication($user, $client));
        } else {
            $di->instance(Authentication::class, new Authentication($user));
        }
    }

    /**
     * @param string $bearer
     * @return array|null
     */
    public static function verifyToken(string $bearer): ?array
    {
        $token_part = explode('.', substr($bearer, strlen('bearer ')));
        $header = json_decode(base64_url_decode($token_part[0] ?? ''), true);
        $payload = $token_part[1] ?? '';
        $signature = $token_part[2] ?? null;

        $key = $header['key'] ?? null;
        $algo = $header['algo'] ?? '';
        $time = $header['time'] ?? 0;
        $jwt_secret = 'abcdef';
        $addr = $header['addr'] ?? '';

        if (!$addr || $_SERVER['REMOTE_ADDR'] !== $addr) {
            return null;
        }

        if (time() < $time && $algo && hash_hmac($algo, "$key.$payload", $jwt_secret) === $signature) {
            return ['header' => $header, 'payload' => json_decode(base64_url_decode($payload), true)];
        }

        return null;
    }

}
