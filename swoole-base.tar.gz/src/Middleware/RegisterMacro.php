<?php

namespace Src\Middleware;

use Src\Database\Postgres\QueryBuilder;

class RegisterMacro
{
    public function __construct()
    {
        QueryBuilder::macro('clientId', function (QueryBuilder $builder, ?int $id) {
            $builder->whereRaw($builder->getTable() . '.client_id = '.(int)$id);
            return $builder;
        });
    }
}
