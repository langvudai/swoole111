<?php

namespace SwooleBase\Foundation\Interfaces;

interface ExceptionHandler
{
    /**
     * @return mixed
     */
    public function handler(): mixed;
}
