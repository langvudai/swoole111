<?php

namespace Src\Api\Factories\CLIENT1\Services;

class ClientPolicyService implements \Src\Api\Services\ClientPolicyService
{
    public function getPolicy(): array
    {
        return ['client 1'];
    }
}
