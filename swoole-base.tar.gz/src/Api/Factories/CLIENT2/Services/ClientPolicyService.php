<?php

namespace Src\Api\Factories\CLIENT2\Services;

class ClientPolicyService implements \Src\Api\Services\ClientPolicyService
{
    public function getPolicy(): array
    {
        return ['client 2'];
    }
}
