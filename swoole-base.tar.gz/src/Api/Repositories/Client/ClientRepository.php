<?php

namespace Src\Api\Repositories\Client;

use Src\Api\Models\Client\Client;
use Src\Database\DbTable;
use Src\Store\ClientStore;

class ClientRepository
{
    public function getAll(): array
    {
        return ClientStore::all('123456', function () {
            $recordset = DbTable::query('clients')->get();
            $recordset->setModel(Client::class);
            return $recordset->toArray();
        });
    }

    public function getById(int $id): Client
    {
        $client = DbTable::connection()->find('clients', 'id', $id);

        return new Client($client ?? []);
    }
}
