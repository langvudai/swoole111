<?php

namespace Src\Api\Controllers;

use Src\Api\Requests\LoginRequest;
use Src\Database\Entities\User as UserEntity;
use SwooleBase\Foundation\Http\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Class AuthController
 * @package Src\Controllers\Api
 *
 */
class AuthController
{
    const TIME_LIFE = 3600;

    /**
     * @param LoginRequest $request
     * @return JsonResponse
     * @throws \SwooleBase\Foundation\Exception
     */
    public function login(LoginRequest $request): JsonResponse
    {
        $request->throwJsonIfFailed();
        // password_hash('123456', PASSWORD_DEFAULT);
        $username = $request->get('username');
        $password = $request->get('password');
        /** @var null|UserEntity $user */
        $user = UserEntity::findUsername($username);

        if (!$user) {
            return symfony_json_response(false, [], 'Tên đăng nhập không chính xác', 401);
        }

        if (!password_verify($password, $user->password)) {
            return symfony_json_response(false, [], 'Mật khẩu đăng nhập không chính xác', 401);
        }

        $jwt_secret = 'abcdef';
        $key = rand(0, 1000);
        $algo = 'sha256';
        $time = time() + self::TIME_LIFE;
        $addr = $_SERVER['REMOTE_ADDR'];
        $type = 'bearer';
        $header = base64_url_encode(json_encode(compact('algo', 'key', 'time', 'type', 'addr')));
        $payload = base64_url_encode(json_encode([
            'uuid' => $user->uuid,
            'client' => $request->get('client'),
        ]));
        $signature = hash_hmac($algo, "$key.$payload", $jwt_secret);

        return symfony_json_response(true, "$header.$payload.$signature");
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function refreshToken(Request $request): JsonResponse
    {
        $bearer = $request->get('bearer', '');
        $token_part = explode('.', preg_match('/^\s*bearer\s+([^\s]+)/', $bearer, $matches) ? $matches[1] : $bearer);
        $header = json_decode(base64_url_decode($token_part[0] ?? ''), true);
        $payload = $token_part[1] ?? '';
        $signature = $token_part[2] ?? null;
        $jwt_secret = 'abcdef';
        extract($header);
        unset($header);

        if (!isset($addr) || $_SERVER['REMOTE_ADDR'] !== $addr) {
            return symfony_json_response(false, null, 'REMOTE_ADDR');
        }

        if (!isset($time) || time() >= $time) {
            return symfony_json_response(false, null, 'time');
        }

        if (!isset($algo) || !isset($signature) || !isset($key) || !hash_hmac($algo, "$key.$payload", $jwt_secret) === $signature) {
            return symfony_json_response(false, null, 'hash_hmac');
        }

        $time = time() + self::TIME_LIFE;
        $header = base64_url_encode(json_encode(compact('algo', 'key', 'time', 'type', 'addr')));
        $signature = hash_hmac($algo, "$key.$payload", $jwt_secret);

        return symfony_json_response(true, "$header.$payload.$signature");
    }
}
