<?php

namespace Src\Api\Controllers;

use Src\Command\ExampleBackgroundWorkCommand;
use Src\Api\Services\ClientPolicyService;
use Src\Api\Services\ClientService;
use SwooleBase\Foundation\DI;
use Symfony\Component\HttpFoundation\JsonResponse;
use function SwooleBase\Foundation\console;

/**
 * Class ClientController
 * @package Src\Controllers\Api
 */
class ClientController
{
    private $client_service;

    public function __construct(ClientService $service)
    {
        $bindings = console(DI::class, '$bindings');

        console(DI::class, '$bindings', array_replace_recursive($bindings, [
            ClientPolicyService::class => [
                'CLIENT1' => \Src\Api\Factories\CLIENT1\Services\ClientPolicyService::class,
                'CLIENT2' => \Src\Api\Factories\CLIENT2\Services\ClientPolicyService::class,
            ]
        ]));

        $this->client_service = $service;
    }

    /**
     * @return JsonResponse
     */
    public function index(): JsonResponse
    {
        return symfony_json_response(true, $this->client_service->getAll());
    }

    /**
     * @param int $id
     * @return JsonResponse
     */
    public function show(int $id): JsonResponse
    {
        return symfony_json_response(true, $this->client_service->getById($id));
    }

    /**
     * @return JsonResponse
     */
    public function backgroundWork(): JsonResponse
    {
        $bgw = new ExampleBackgroundWorkCommand(['client_id' => 1]);
        return symfony_json_response($bgw->publish());
    }

    /**
     * @param ClientPolicyService $service
     * @return JsonResponse
     */
    public function policy(ClientPolicyService $service): JsonResponse
    {
        return symfony_json_response(true, $service->getPolicy());
    }
}
