<?php

namespace Src\Api;

use Src\Api\Controllers\AuthController;
use Src\Api\Controllers\ClientController;
use SwooleBase\Foundation\Http\RouteCollector;

class Api implements \SwooleBase\Foundation\Interfaces\Router
{

    public function __construct(RouteCollector $router)
    {
        $router->get('/enum/{enum}', ['middleware' =>'cors', 'as' => 'api.enum'], function ($enum) {
            try {
                $pascal = pascal_case($enum);

                return symfony_json_response(true, call_user_func(["Src\\Enum\\$pascal", 'fetch']));
            } catch (\Throwable $exception) {
                return symfony_json_response(false, $exception->getTrace(), $exception->getMessage());
            }
        });

        $router->post('/login', ['as' => 'api.login'], [AuthController::class,'login']);
        $router->get('/refresh-token', ['as' => 'api.login'], [AuthController::class,'refreshToken']);
        $router->get('/client', ['as' => 'api.client.index'], [ClientController::class, 'index']);
        $router->get('/client/policy', ['as' => 'api.client.policy', 'middleware' => ['cors', 'auth:api']], [ClientController::class, 'policy']);
        $router->get('/client/{id}', ['as' => 'api.client.show'], [ClientController::class, 'show']);
        $router->get('/background-work', [ClientController::class, 'backgroundWork']);
    }
}