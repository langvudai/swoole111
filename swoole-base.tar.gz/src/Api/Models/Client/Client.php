<?php

namespace Src\Api\Models\Client;

use SwooleBase\Foundation\Abstracts\Json;

class Client extends Json
{
    protected array $hidden = [
        'updated_at',
        'deleted_time',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    public function __construct(array $data)
    {
        $this->data = $data;
    }

    public static function transform(): array
    {
        return [
            'created_at' => fn($data) => self::formatDate($data, 'd/m/Y'),
        ];
    }
}
