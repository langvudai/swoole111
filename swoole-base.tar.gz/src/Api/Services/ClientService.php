<?php

namespace Src\Api\Services;

use Src\Api\Models\Client\Client;
use Src\Api\Repositories\Client\ClientRepository;

class ClientService
{
    private $client_repository;

    public function __construct(ClientRepository $repository)
    {
        $this->client_repository = $repository;
    }

    /**
     * @return array
     */
    public function getAll(): array
    {
        return $this->client_repository->getAll();
    }

    /**
     * @param int $id
     * @return Client
     */
    public function getById(int $id): Client
    {
        return $this->client_repository->getById($id);
    }
}